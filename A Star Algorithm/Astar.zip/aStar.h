#pragma once
void search(int** map, const int size);